package com.spring_security_app.enums;

public enum ERole {
  ROLE_USER,
  ROLE_MODERATOR,
  ROLE_ADMIN,
  ROLE_EMPLOYEE
}
